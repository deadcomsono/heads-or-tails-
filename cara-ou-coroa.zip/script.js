
function jogarMoeda() {
  return Math.random() < 0.5 ? 'Cara' : 'Coroa';
}

function melhorDeTres() {
  let yokai = 0;
  let dead = 0;
  let texto = '';

  for (let i = 1; i <= 3; i++) {
    const resultado = jogarMoeda();
    texto += `Rodada ${i}: ${resultado}\n`;

    if (resultado === 'Cara') {
      yokai++;
    } else {
      dead++;
    }

    if (yokai === 2 || dead === 2) break;
  }

  const vencedor = yokai > dead ? 'YokaiTristezaPura' : 'DeadTristezaPura';
  texto += `\nVENCEDOR: ${vencedor}`;
  document.getElementById('resultado').textContent = texto;
}
